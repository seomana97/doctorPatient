<!DOCTYPE html>
<html>
<head>
	<title>Doctor Patient</title>
	<link rel="stylesheet"  href="doctorpatient.css">

	<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&family=Open+Sans:wght@300&display=swap" rel="stylesheet">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width">
	<meta http-equiv="X-UA-Compatible" content="id=edge">
</head>

<body>
	<div class="wrapper">
		<div class="btn" > <a href="login3.php">

<button type="button" class="buttonA" > Admin</button>

</div>

</div>


	<div class="wrapper" style="text-decoration: none;">
	<div class="btn" > <a href="login.php"  >
<button type="button" class="buttonP">Patient</button>
</div>

</div>


	<div class="wrapper" style="text-decoration: none;">
	<div class="btn" > <a href="login2.php"  >
<button type="button" class="buttonD">Doctor</button>
        </a>
</div>

</div>

	


 
	




</body>
</html>